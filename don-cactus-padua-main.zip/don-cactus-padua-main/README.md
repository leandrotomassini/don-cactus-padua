![](https://scontent.fepa2-1.fna.fbcdn.net/v/t1.6435-9/79662046_1516949381795098_4172205121951760384_n.jpg?_nc_cat=101&ccb=1-5&_nc_sid=973b4a&_nc_ohc=syEwu9xWQ90AX_VCKIQ&_nc_ht=scontent.fepa2-1.fna&oh=5232e7b6977d17e8aab6d4d1f5e893f6&oe=616A087F)
# Don cactus padua
Don Cactus Growshop. Lunes a sábados. De 11 a 19!! ❤ Limay 21. San Antonio de Padua ✊ Ventas mayorista @doncactusdistrigrow
